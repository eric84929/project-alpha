$(document).ready(function() {

    var thisUserAccount ;    

    $(document).ready(function() {
    	thisUserAccount= $().SPServices.SPGetCurrentUser({
    		fieldName: "Title",
    		debug: false
		});

	$("#username").html(thisUserAccount);
	$("#username2").html(thisUserAccount);

 	}); 

});