var ListData = [];
var TableHTML;
var ISINListHTML;
var YTW_Low;
var YTW_High;
var Years_Low;
var Years_High;
var Rating_Low;
var Rating_High;

var ytwlow;
var ytwhigh;
var yearslow;
var yearshigh;
var ratinghigh;
var ratinglow;

$(document).ready(function() {
	document.getElementById('ytwhigh').value = getSavedValue("ytwhigh");
	document.getElementById('ytwlow').value = getSavedValue("ytwlow");
	document.getElementById('yearshigh').value = getSavedValue("yearshigh");
	document.getElementById('yearslow').value = getSavedValue("yearslow");
	document.getElementById('ratinghigh').value = getSavedValue("ratinghigh");
	document.getElementById('ratinglow').value = getSavedValue("ratinglow");
	document.getElementById('ISIN').value = getSavedValue("ISIN");
	GetISINList();
	GetInputParameters();
	GetListItems();
	PopulateTable();
	$("#submit").click(function(){
		GetInputParameters();
		location.reload();
	})
	$("#reset_btn").click(function(){
		document.getElementById('ytwhigh').value = "";
		document.getElementById('ytwlow').value = "";
		document.getElementById('yearshigh').value = "";
		document.getElementById('yearslow').value = "";
		document.getElementById('ratinghigh').value = "";
		document.getElementById('ratinglow').value = "";
		sessionStorage.clear();
	})
	$("#submit-ISIN").click(function(){
		sessionStorage.setItem("ISIN", document.getElementById('ISIN').value);
		SearchISIN();
	})
	$("#reset-ISIN").click(function(){
		document.getElementById('ISIN').value = "";
	})
});

function SearchISIN()
{
	console.log("starting Search ISIN");
	var ISINTarget = document.getElementById('ISIN').value;

	var TargetYTW;
	var TargetYears;
	var TargetRating;

	if (ISINTarget.length != 0)
	{
		console.log("ISIN target not null");
		var myQuery	= "<Query>"+
						"<Orderby>"+
							"<FieldRef Name = 'ISIN'/>"+
						"</Orderby>"+
						"<Where>"+
							"<Eq>"+
								"<FieldRef Name = 'ISIN'/>"+
								"<Value Type='Text'>" + ISINTarget + "</Value>"+
							"</Eq>"+
						"</Where>"+
					"</Query>";

		$().SPServices({
	    operation: "GetListItems",
	    async: false,
	    listName: "DB",
	    CAMLQuery: myQuery,
	    CAMLRowLimit: 1,
	    CAMLViewFields: "<ViewFields>"+
							"<FieldRef Name='YTW_x0025_' />"+
							"<FieldRef Name='LTW_x002c__x0020_yrs' />"+
							"<FieldRef Name='Avg_x0020_Num_x0020_Rating' />"+
						"</ViewFields>",
	    completefunc: function (xData, Status) {
	      $(xData.responseXML).SPFilterNode("z:row").each(function() {
	        	TargetYTW = $(this).attr("ows_YTW_x0025_");
	        	TargetYears = $(this).attr("ows_LTW_x002c__x0020_yrs");
	        	TargetRating = $(this).attr("ows_Avg_x0020_Num_x0020_Rating");
		      });
		    }
  });
  		var NumTargetYTM = parseFloat(TargetYTW);
  		NumTargetYTM *= 100;
  		NumTargetYTM = NumTargetYTM.toFixed(6);
  		var NumTargetYears = parseFloat(TargetYears);
  		NumTargetYears = NumTargetYears.toFixed(4);
  		var NumTargetRating = parseFloat(TargetRating);		
  		NumTargetRating = NumTargetRating.toFixed(2);		
		sessionStorage.setItem("ytwhigh", (NumTargetYTM * 1.5).toFixed(4));
		sessionStorage.setItem("ytwlow", (NumTargetYTM * 0.95).toFixed(4));
		sessionStorage.setItem("yearshigh", NumTargetYears+2);
		sessionStorage.setItem("yearslow", (NumTargetYears-3));
		sessionStorage.setItem("ratinghigh", NumTargetRating);
		sessionStorage.setItem("ratinglow", NumTargetRating - 5);
		location.reload();
	}
}

function GetISINList()
{
	var myQuery = "<Query>"+
						"<Orderby>"+
							"<FieldRef Name = 'ISIN'/>"+
						"</Orderby>"+
						"<Where>"+
							"<IsNotNull>"+
								"<FieldRef Name = 'ISIN'/>"+
							"</IsNotNull>"+
						"</Where>"+
					"</Query>";

	$().SPServices({
	    operation: "GetListItems",
	    async: false,
	    listName: "DB",
	    CAMLQuery: myQuery,
	    CAMLRowLimit: 1000,
	    CAMLViewFields: "<ViewFields>"+
							"<FieldRef Name='ISIN' />"+
						"</ViewFields>",
	    completefunc: function (xData, Status) {
	      $(xData.responseXML).SPFilterNode("z:row").each(function() {
	        	var ISIN = $(this).attr("ows_ISIN");
	        	ISINListHTML += "<option value ='";
	        	ISINListHTML += ISIN;
	        	ISINListHTML += "'>";
		      });
		    }
  });
	$("#bonds").html(ISINListHTML);
}

function GetInputParameters()
{
	var allEmpty = true;

	if (document.getElementById('ytwhigh').value.length != 0)
	{
		YTW_High = parseFloat(document.getElementById('ytwhigh').value);
		YTW_High /= 100;
		allEmpty = false;
	}
	else 
	{
		YTW_High = 100;
	}
	if (document.getElementById('ytwlow').value.length != 0)
	{
		YTW_Low = parseFloat(document.getElementById('ytwlow').value);
		YTW_Low /= 100;
		allEmpty = false;
	}
	else
	{
		YTW_Low = 0;
	}
	if (document.getElementById('yearshigh').value.length != 0)
	{
		Years_High = document.getElementById('yearshigh').value;
		allEmpty = false;
	}
	else
	{
		Years_High = 100;
	}
	if (document.getElementById('yearslow').value.length != 0)
	{
		Years_Low = document.getElementById('yearslow').value;
		allEmpty = false;
	}
	else
	{
		Years_Low = 0;
	}
	if (document.getElementById('ratinghigh').value.length != 0)
	{
		Rating_High = document.getElementById('ratinghigh').value;
		allEmpty = false;
	}
	else
	{
		Rating_High = 20;
	}
	if (document.getElementById('ratinglow').value.length != 0)
	{
		Rating_Low = document.getElementById('ratinglow').value;
		allEmpty = false;
	}
	else
	{
		Rating_Low = 0;
	}
	if (allEmpty == true)
	{
		YTW_High = 0;
		YTW_Low = 0;
		Years_High = 0;
		Years_Low = 0;
		Rating_High = 0;
		Rating_Low = 0;
	}
	
	GetListItems();
	PopulateTable();
}

function PopulateTable()
{
	for (var i = 0; i < ListData.length; i++)
	{
		TableHTML += "<tr>";
		for (var j = 0; j < ListData[i].length; j++)
		{
			TableHTML += "<th>";
			TableHTML += ListData[i][j];
			TableHTML += "</th>"
		}
		TableHTML += "</tr>";
	}

	$("#TableData").html(TableHTML);
}

function GetListItems()
{
		var myQuery = 
       "<Query>" +
          "<Where>" +
             "<And>" +
             	"<Leq>"+
             		"<FieldRef Name='Avg_x0020_Num_x0020_Rating' />"+
             		"<Value Type = 'Number'>"+ Rating_High + "</Value>"+
             	"</Leq>"+
             	"<And>"+
             		"<Geq>"+
             			"<FieldRef Name='Avg_x0020_Num_x0020_Rating' />"+
             			"<Value Type = 'Number'>" + Rating_Low + "</Value>"+
             		"</Geq>"+
             		"<And>"+
             			"<Leq>"+
             				"<FieldRef Name='LTW_x002c__x0020_yrs' />"+
             				"<Value Type = 'Number'>"+ Years_High +"</Value>"+
             			"</Leq>"+
             			"<And>"+
             				"<Geq>"+
             					"<FieldRef Name='LTW_x002c__x0020_yrs' />"+
             					"<Value Type = 'Number'>" + Years_Low + "</Value>"+
             				"</Geq>"+
         					"<And>"+
         						"<IsNotNull>"+
         							"<FieldRef Name='ISIN' />"+
         						"</IsNotNull>"+
         						"<And>"+
         							"<Geq>"+
         								"<FieldRef Name='YTW_x0025_' />"+
         								"<Value Type = 'Number'>"+ YTW_Low +"</Value>"+
         							"</Geq>"+
         							"<Leq>"+
         								"<FieldRef Name='YTW_x0025_' />"+
         								"<Value Type = 'Number'>"+ YTW_High +"</Value>"+
         							"</Leq>"+
         						"</And>"+
         					"</And>"+
             			"</And>"+
             		"</And>"+
             	"</And>"+
             "</And>"+
          "</Where>" +
       "</Query>";


  	$().SPServices({
	    operation: "GetListItems",
	    async: false,
	    listName: "DB",
	    CAMLQuery: myQuery,
	    CAMLRowLimit: 1000,
	    CAMLViewFields: "<ViewFields>"+
							"<FieldRef Name='ISIN' />"+
							"<FieldRef Name='Ticker' />"+
							"<FieldRef Name='Issuer' />"+
							"<FieldRef Name='YTW_x0025_' />"+
							"<FieldRef Name='Maturity' />"+
							"<FieldRef Name='NxtCall' />"+
							"<FieldRef Name='Tenor' />"+
							"<FieldRef Name='Z_x002d_SPRD' />"+
							"<FieldRef Name='Issue_x0020_Notional' />"+
							"<FieldRef Name='Moodys_x0020_Rating' />"+
							"<FieldRef Name='SP_x0020_Rating' />"+
							"<FieldRef Name='Fitch_x0020_Rating' />"+
							"<FieldRef Name='Sector' />"+
							"<FieldRef Name='Sub_x002f_Sector' />"+
							"<FieldRef Name='IS_x0020_CALL' />"+
							"<FieldRef Name='IS_x0020_PERP' />"+
							"<FieldRef Name='IS_x0020_SUB' />"+
						"</ViewFields>",
	    completefunc: function (xData, Status) {
	      $(xData.responseXML).SPFilterNode("z:row").each(function() {
	        	var ISIN = $(this).attr("ows_ISIN");
	        	var Ticker = $(this).attr("ows_Ticker");
	        	var Issuer =$(this).attr("ows_Issuer");
	        	var YTW = parseFloat($(this).attr("ows_YTW_x0025_"));
	        	YTW = YTW * 100;
	        	YTW = YTW.toFixed(4);
	        	var Maturity = $(this).attr("ows_Maturity");
	        	var NxtCall = $(this).attr("ows_NxtCall");
	        	var Tenor = parseInt($(this).attr("ows_Tenor")).toFixed(0);;
	        	var ZSprd = parseFloat($(this).attr("ows_Z_x002d_SPRD")).toFixed(4);
	        	var IssueNotional = parseInt($(this).attr("ows_Issue_x0020_Notional"));
	        	var Moodys = $(this).attr("ows_Moodys_x0020_Rating");
	        	var SP = $(this).attr("SP_x0020_Rating");
	        	var Fitch = $(this).attr("ows_Fitch_x0020_Rating");
	        	var Sector = $(this).attr("ows_Sector");
	        	var SubSector = $(this).attr("ows_Sub_x002f_Sector");
	        	var Call = $(this).attr("ows_IS_x0020_CALL");
	        	var Perp = $(this).attr("ows_IS_x0020_PERP");
	        	var Sub = $(this).attr("ows_IS_x0020_SUB");
	        	ListData.push([ISIN, Ticker, Issuer, YTW, Maturity, NxtCall,Tenor, ZSprd, IssueNotional, Moodys, SP, Fitch, Sector, SubSector, Call, Perp, Sub]);
		      });
		    }
  });

}

function getSavedValue  (v){
    if (sessionStorage.getItem(v) === null) {
        return "";// You can change this to your defualt value. 
    }
    return sessionStorage.getItem(v);
}

function saveValue(e){
    var id = e.id;  // get the sender's id to save it . 
    var val = e.value; // get the value. 
    sessionStorage.setItem(id, val);// Every time user writing something, the localStorage's value will override . 
}
